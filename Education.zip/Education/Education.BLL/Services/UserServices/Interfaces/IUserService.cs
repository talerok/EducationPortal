﻿using System;
using System.Collections.Generic;
using System.Text;
using Education.BLL.DTO.User;
using System.Security.Claims;
using System.Threading.Tasks;
using Education.DAL.Entities;
using Education.BLL.Logic;

namespace Education.BLL.Services.UserServices.Interfaces
{
    public enum AuthStatus
    {
        Succsess,
        UserNotFound,
        UserBanned,
        WrongKey,
        NeedNewKey,
        KeySent,
        Other
    }

    public interface IUserService
    {
        AuthResult Login(string login, string pass, string secretKey);
        UserDTO GetUser(IEnumerable<Claim> claims);
        RegisterResult Register(UserDTO user);
    }
}
