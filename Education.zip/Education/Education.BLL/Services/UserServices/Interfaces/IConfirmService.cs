﻿using Education.BLL.DTO.User;
using System;
using System.Collections.Generic;
using System.Text;

namespace Education.BLL.Services.UserServices.Interfaces
{
    enum ConfirmCode
    {
        Success,
        KeySend,
        Fail,
        NeedNewKey,
        AlreadyExist
    }

    interface IConfirmService
    {
        ConfirmCode Set(UserDTO userDTO, string Value);
        ConfirmCode CheckSet(UserDTO userDTO, string Key);
        ConfirmCode Remove(UserDTO userDTO);
        ConfirmCode CheckRemove(UserDTO userDTO, string Key);
    }
}
