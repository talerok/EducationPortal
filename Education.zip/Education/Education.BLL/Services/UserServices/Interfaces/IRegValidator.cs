﻿using Education.BLL.DTO.User;
using System;
using System.Collections.Generic;
using System.Text;

namespace Education.BLL.Services.UserServices.Interfaces
{
    public enum RegisterResult
    {
        Confirm,
        WrongLogin,
        WrongEmail,
        WrongPhone,
        WrongPassword,
        WrongFullName,
        LoginAlreadyExists,
        EmailAlreadyExists,
        PhoneAlreadyExists
        
    };

    public interface IRegValidator
    {
        RegisterResult Check(UserDTO userDTO);
    }
}
