﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Education.BLL.Services.UserServices.Messagers
{
    public class SmsMessenger : Interfaces.IMessenger
    {
        public void Send(string to, string text)
        {
            int i = 1;
        }
    }
}
