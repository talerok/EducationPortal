﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Education.BLL.Services.UserServices.Messengers
{
    public class EmailMessenger : Interfaces.IMessenger
    {
        public void Send(string to, string text)
        {
            int i = 1;
        }
    }
}
