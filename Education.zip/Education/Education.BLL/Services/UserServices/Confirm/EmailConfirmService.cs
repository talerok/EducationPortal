﻿using Education.BLL.DTO.User;
using Education.BLL.Logic;
using Education.BLL.Services.UserServices.Interfaces;
using Education.DAL.Entities;
using Education.DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Education.BLL.Services.UserServices.Confirm
{
    class EmailConfirmService : IConfirmService
    {
        private IAuthKeyService keyService;
        private IUOW Data;

        private User GetUser(UserDTO user)
        {
            User dbUser = Data.UserRepository.Get().FirstOrDefault(x => x.Login == user.Login
            || x.Phone != null && x.Phone.Value == user.PhoneNumber
            || x.Email != null && x.Email.Value == user.Email);
            if (user == null) throw new UserAuthException(AuthError.UserNotFound);
            return dbUser;
        }

        public ConfirmCode CheckSet(UserDTO userDTO, string Key)
        {
            User user = GetUser(userDTO);
            if (user.Email == null) throw new ConfirmException(ConfirmError.NotFound);
            var keyStatus = keyService.Check(user.Email, Key);
            if (keyStatus == KeyStatus.Success)
            {
                user.Email.Confirmed = true;
                Data.ContactRepository.Edited(user.Email);
                return ConfirmCode.Success;
            }
            else if (keyStatus == KeyStatus.KeyTimeEnded) return ConfirmCode.NeedNewKey;
            return ConfirmCode.Fail;
        }

        public ConfirmCode CheckRemove(UserDTO userDTO, string Key)
        {
            User user = GetUser(userDTO);
            if (user.Email == null) throw new ConfirmException(ConfirmError.NotFound);
            var keyStatus = keyService.Check(user.Email, Key);
            if (keyStatus == KeyStatus.Success)
            {
                Data.ContactRepository.Delete(user.Email);
                return ConfirmCode.Success;
            }
            else if (keyStatus == KeyStatus.KeyTimeEnded) return ConfirmCode.NeedNewKey;
            return ConfirmCode.Fail;
        }

        public ConfirmCode Remove(UserDTO userDTO)
        {
            User user = GetUser(userDTO);
            if (user.Email == null) throw new ConfirmException(ConfirmError.NotFound);
            else if (!user.Email.Confirmed)
            {
                Data.ContactRepository.Delete(user.Email);
                return ConfirmCode.Success;
            }
            else keyService.Generate(user.Email);
            return ConfirmCode.KeySend;
        }

        public ConfirmCode Set(UserDTO userDTO, string Value)
        {
            User user = GetUser(userDTO);
            if (user.Email != null) throw new ConfirmException(ConfirmError.AlreadySet);
            if (Data.ContactRepository.Get().FirstOrDefault(x => x.Value == Value) != null)
                return ConfirmCode.AlreadyExist;
            user.Email = new Contact
            {
                Confirmed = false,
                Value = Value
            };
            Data.UserRepository.Edited(user);
            keyService.Generate(user.Email);
            return ConfirmCode.KeySend;
        }
    }
}
