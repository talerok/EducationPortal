﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Linq;
using Education.BLL.DTO.User;
using Education.BLL.Logic;
using Education.DAL.Entities;
using Education.DAL.Interfaces;
using Education.BLL.Services.UserServices.Interfaces;

namespace Education.BLL.Services.UserServices.Auth
{
    public class UserAuthService : Interfaces.IUserService
    {
        private IUOW Data;
        private IAuthKeyService EmailAuthService;
        private IAuthKeyService PhoneAuthService;
        private IPassHasher PassHasher;
        private IRegValidator RegValidator;
        public UserAuthService(IUOW iuow, 
            IAuthKeyService phoneAuthService, 
            IAuthKeyService emailAuthService, 
            IPassHasher passHasher,
            IRegValidator regValidator)
        {
            Data = iuow;
            EmailAuthService = emailAuthService;
            PhoneAuthService = phoneAuthService;
            PassHasher = passHasher;
            RegValidator = regValidator;
        }
       
        private ClaimsIdentity Generate(User user)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimsIdentity.DefaultNameClaimType, user.Login),
            }; 
            return new ClaimsIdentity(claims, "ApplicationCookie");
        }

        private User Generate(IEnumerable<Claim> claims)
        {
            var a = claims.FirstOrDefault(x => x.Type == ClaimsIdentity.DefaultNameClaimType);
            if (a == null) return null;
            var user = Data.UserRepository.Get().FirstOrDefault(x => x.Login == a.Value);
            return user;
        }

        private User GetUser(string login, string pass)
        {
            return Data.UserRepository.Get().FirstOrDefault(
                x => 
                x.Password == PassHasher.Get(pass) 
                && 
                x.Login == login.ToLower()
                || 
                x.Phone != null && x.Phone.Confirmed && x.Phone.Value == login.ToLower()
                || 
                x.Email != null && x.Email.Confirmed && x.Email.Value == login.ToLower());
        }

        private AuthResult KeyLogin(User user, string secretKey)
        {
            KeyStatus keyStatus;
            if (user.authType == AuthType.Email) keyStatus = EmailAuthService.Check(user.Email, secretKey);
            else if (user.authType == AuthType.Phone) keyStatus = PhoneAuthService.Check(user.Phone, secretKey);
            else throw new UserAuthException(AuthError.AuthTypeNotFound);
            if (keyStatus == KeyStatus.Success)
                return new AuthResult { Status = AuthStatus.Succsess, Identity = Generate(user) };
            else if (keyStatus == KeyStatus.KeyTimeEnded) return new AuthResult { Status = AuthStatus.NeedNewKey };
            return new AuthResult { Status = AuthStatus.WrongKey };

        }

        private AuthResult SendKey(User user)
        {
            DateTime keyTime;
            if (user.authType == AuthType.Email) keyTime = EmailAuthService.Generate(user.Email);
            else if (user.authType == AuthType.Phone) keyTime = PhoneAuthService.Generate(user.Phone);
            else throw new UserAuthException(AuthError.AuthTypeNotFound);
            return new AuthResult { Status = AuthStatus.KeySent, authType = user.authType, KeyTime = keyTime };
        }

        public AuthResult Login(string login, string pass, string secretKey)
        {
            User user = GetUser(login, pass);
            if (user == null) return new AuthResult { Status = AuthStatus.UserNotFound };
            if (user.Ban != null)
            {
                if (user.Ban.EndTime < DateTime.Now) return new AuthResult { Status = AuthStatus.UserBanned, KeyTime = user.Ban.EndTime, Comment = user.Ban.Reason };
                else Data.BanRepository.Delete(user.Ban);
            }
            if (user.authType == AuthType.Simple)
                return new AuthResult { Status = AuthStatus.Succsess, Identity = Generate(user) };
            else if (!String.IsNullOrEmpty(secretKey)) return KeyLogin(user, secretKey);
            else return SendKey(user);
        }

        public UserDTO GetUser(IEnumerable<Claim> claims)
        {
            var user = Generate(claims);
            if (user == null) return null;
            if (user.Ban != null && DateTime.Now < user.Ban.EndTime) return null;
            var userDTO = new UserDTO
            {
                Id = user.Id,
                Login = user.Login,
                Email = user.Email?.Value,
                PhoneNumber = user.Phone?.Value,
                FullName = user.Info?.FullName,
                Password = user.Password     
            };
            return userDTO;
        }
                     
        public RegisterResult Register(UserDTO userDTO)
        {        
            var info = new UserInfo { FullName = userDTO.FullName };
            var check = RegValidator.Check(userDTO);
            if (check != RegisterResult.Confirm) return check;
            var newUser = new User
            {
                Info = info,
                Login = userDTO.Login.ToLower(),
                Password = PassHasher.Get(userDTO.Password)
            };

            var email = new Contact { Value = userDTO.Email.ToLower(), Confirmed = false };
            var phone = new Contact { Value = userDTO.PhoneNumber, Confirmed = false };

            newUser.Phone = phone;
            newUser.Email = email;
            return RegisterResult.Confirm;
        }

    }
}
