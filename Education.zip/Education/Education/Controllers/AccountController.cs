﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Education.BLL.Services.UserServices.Interfaces;
using Education.BLL.DTO.User;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Education.BLL.Logic;
using Education.Models;

namespace Education.Controllers
{
    public class AccountController : Controller
    {
        private IUserService userService;

        public AccountController(IUserService service)
        {
            userService = service;
        }

        [Authorize]
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }

        [Authorize]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login");
        }

        #region Auth
        [HttpPost]
        public async Task<AuthResponse> Auth(AuthRequest request)
        {
            try
            {
                AuthResult res = userService.Login(request.Login, request.Password, request.SecretKey);
                if (res.Status == AuthStatus.Succsess)
                    await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(res.Identity));
                return new AuthResponse { AuthType = res.authType, KeyTime = res.KeyTime, Status = res.Status };

            }
            catch { return new AuthResponse { Status = AuthStatus.Other }; }
        }
        #endregion

       
    }
}
